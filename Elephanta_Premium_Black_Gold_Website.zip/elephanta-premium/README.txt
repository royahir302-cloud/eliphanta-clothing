ELEPHANTA CLOTHING — PREMIUM BLACK/GOLD WEBSITE
Upload all files to the root of your GitHub repository.
Keep index.html in the root. GitHub Pages: main / (root).
WhatsApp: +91 95105 84191.
This is a front-end store demo; real payment/admin/inventory needs a backend.
